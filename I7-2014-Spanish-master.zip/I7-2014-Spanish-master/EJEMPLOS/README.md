EJEMPLOS infsp7
======

Algunas historias de ejemplo.

�C�mo correr los ejemplos?

1. Inicia un nuevo proyecto en I7, llamado "ejemplo_SL" o algo parecido.
2. Copia el contenido del ejemplo xxxxxxx.ni en la pesta�a 'Source' de tu I7.
     (puedes usar el notepad de Windows para cortar y pegar, o cualquier otro editor Unicode UTF-8).
3. Si se trata de un juego grande, debes extender la capacidad de la maquina Z. En la pesta�a 'Settings' de I7, marca Z-Code Version 8 o Glulx.     
4. Pulsa boton 'Go!'
5. Juega, explora, mete mano. As� se aprende.

Notas de desarrollo y programaci�n en:
http://wiki.caad.es/Inform7_6L02
