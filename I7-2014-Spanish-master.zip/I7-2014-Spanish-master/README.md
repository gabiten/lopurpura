infsp7
======

Inform 7 Spanish Libs

Edici�n 6M62 (Diciembre 2015)

[Tutorial](https://github.com/sarganar/I7-2014-Spanish/wiki)

[Notas de desarrollo y programaci�n](http://wiki.caad.es/Inform7_6L02)
